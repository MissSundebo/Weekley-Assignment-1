const getPayElement= document.getElementById('getPay')
const getBankButtonElement= document.getElementById('getBank')
const getWorkButtonElement= document.getElementById('getWork');

let pay = 0;

