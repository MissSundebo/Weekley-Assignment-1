const balanceElement = document.getElementById('balance');
const getALoanButtonElement = document.getElementById('getALoan');

let balance = 0;

